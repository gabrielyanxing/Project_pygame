import pygame
import random
import time
import mysql.connector

def connect_to_db():
    connection= mysql.connector.connect(
        user="luoying",
        password="mypassword",
        host="localhost",
        port=3306,
        database="airport",
        autocommit = True,
        charset="utf8mb4",
        collation= "utf8mb4_general_ci"
    )
    return connection

# 根据机场代码查询信息
def get_airport_info(airport_codes):
    connection = connect_to_db()
    try:
        with connection.cursor() as cursor:
            # 创建查询语句，使用IN关键字查询多个机场
            sql = "SELECT ident, name, latitude_deg, longitude_deg FROM airport WHERE ident IN (%s)" % ','.join(
                ['%s'] * len(airport_codes))
            cursor.execute(sql, airport_codes)

            results = cursor.fetchall()  # 获取所有查询结果

            airport_info = {}
            for result in results:
                airport_info[result[0]] = {
                    "name": result[1],
                    "latitude": result[2],
                    "longitude": result[3]
                }
            return airport_info
    finally:
        cursor.close()  # 确保关闭游标
        connection.close()  # 确保关闭连接

def load_game_logo():
    """加载并显示游戏Logo，显示2秒后消失"""
    screen.blit(logo_image, (screen_width // 2 - logo_image.get_width() // 2,
                              screen_height // 2 - logo_image.get_height() // 2))
    pygame.display.update()  # 更新屏幕
    time.sleep(2)  # 显示2秒

def input_player_name():
    """要求用户输入玩家姓名"""
    player_name = ""      # 初始化玩家姓名为空字符串
    input_active = True   # 输入框活动状态标志

    while input_active:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:  # 检测是否关闭窗口
                input_active = False

            if event.type == pygame.KEYDOWN:  # 检测键盘按下事件
                if event.key == pygame.K_RETURN:  # 按下回车键，结束输入
                    input_active = False
                elif event.key == pygame.K_BACKSPACE:  # 按下退格键，删除最后一个字符
                    player_name = player_name[:-1]   # 更新姓名，去掉最后一个字符
                else:  # 其他键
                    if len(player_name) < 12:  # 限制姓名长度为12字节
                        player_name += event.unicode  # 将按下的键的字符添加到姓名中

        # 填充屏幕，绘制输入框
        screen.fill((0, 0, 0))  # 填充黑色背景
        input_text = font.render("Enter your name: " + player_name, True, (255, 255, 255))
        screen.blit(input_text, (screen_width // 2 - input_text.get_width() // 2 ,
                                  screen_height // 2 - input_text.get_height() // 2))
        pygame.display.update()  # 更新屏幕

    return player_name

def update_background():
    global background_x1, background_x2, loop_count

    # 更新背景位置
    background_x1 -= background_speed  # 第一张背景向左移动
    background_x2 -= background_speed  # 第二张背景向左移动

    # 如果背景移出了屏幕右侧，将它重新放置到左边
    if background_x1 <= -background_width:
        background_x1 = background_width
        loop_count += 1  # 每当背景循环一次，计数器加1

    if background_x2 <= -background_width:
        background_x2 = background_width
        loop_count += 1  # 同样，计数器加1

    return loop_count

def draw_game_screen_and_airport_info(bell_count, health, player_name, hel_info):
    # 提取机场信息
    airport_name = hel_info['name'] if hel_info else "Unknown Airport"
    latitude = f"Lat: {hel_info['latitude']:.6f}" if hel_info else "Lat: N/A"
    longitude = f"Lon: {hel_info['longitude']:.6f}" if hel_info else "Lon: N/A"

    # 绘制背景
    screen.blit(background_image, (background_x1, 0))  # 绘制第一张背景
    screen.blit(background_image, (background_x2, 0))  # 绘制第二张背景

    # 绘制血量图标
    blood_image_resized = pygame.transform.scale(blood_image, (30, 35))  # 调整血量图片大小
    blood_x = screen_width // 2 - 60  # 血量图标的 x 坐标
    screen.blit(blood_image_resized, (blood_x, 2))  # 绘制血量图标

    # 绘制玩家姓名
    name_text = font.render(player_name, True, (255, 255, 255))
    name_x = blood_x - name_text.get_width() - 10  # 计算姓名文本的 x 坐标
    screen.blit(name_text, (name_x, 5))  # 在顶部中间绘制姓名

    # 绘制铃铛图片和计数
    bell_image_resized = pygame.transform.scale(bell_image, (30, 35))  # 调整铃铛图片大小
    screen.blit(bell_image_resized, (10, 2))  # 绘制铃铛图片

    # 绘制铃铛计数
    bell_count_text = font.render(f"{bell_count}", True, (255, 255, 255))
    screen.blit(bell_count_text, (50, 10))  # 绘制铃铛数量，位置调整到铃铛图标右侧

    # 绘制当前血量计数
    health_text = font.render(f"{health}/5", True, (255, 255, 255))
    screen.blit(health_text, (screen_width // 2 - 20, 10))  # 绘制血量数量

    # 绘制机场信息
    info_text = font.render(f"{airport_name}", True, (255, 255, 255))
    lat_text = font.render(latitude, True, (255, 255, 255))
    lon_text = font.render(longitude, True, (255, 255, 255))

    screen.blit(info_text, (screen_width - info_text.get_width() - 20, 5))
    screen.blit(lat_text, (screen_width - lat_text.get_width() - 20, 25))
    screen.blit(lon_text, (screen_width - lon_text.get_width() - 20, 45))

    pygame.display.update()  # 更新屏幕显示

# 定义铃铛和礼物类
class Bell(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.image.load("bell.png")  # 加载铃铛图像
        self.rect = self.image.get_rect()
        self.rect.x = random.randint(800, 1000)  # 从右侧随机生成
        self.rect.y = random.randint(50, 400)  # 随机高度

    def update(self):
        self.rect.x -= 2  # 向左移动
        if self.rect.x < -self.rect.width:
            self.kill()  # 移出屏幕后删除

class Gift(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.image.load("gift.png")  # 加载礼物图像
        self.rect = self.image.get_rect()
        self.rect.x = random.randint(800, 1000)  # 从右侧随机生成
        self.rect.y = random.randint(50, 400)  # 随机高度

    def update(self):
        self.rect.x -= 2  # 向左移动
        if self.rect.x < -self.rect.width:
            self.kill()  # 移出屏幕后删除

# 定义圣诞袜类
class ChristmasSock(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.image.load("sock.png")  # 加载圣诞袜图像
        self.rect = self.image.get_rect()
        self.rect.x = random.randint(800, 1000)  # 从右侧随机生成
        self.rect.y = random.randint(50, 400)  # 随机高度

    def update(self):
        self.rect.x -= 2  # 向左移动
        if self.rect.x < -self.rect.width:
            self.kill()  # 移出屏幕后删除

# 定义小鸟类
class Bird(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.image.load("bird.png")  # 加载小鸟图像
        self.rect = self.image.get_rect()
        self.rect.x = random.randint(800, 1000)  # 从右侧随机生成
        self.rect.y = random.randint(150, 300)  # 随机高度

    def update(self):
        self.rect.x -= random.randint(4, 7)  # 随机速度
        if self.rect.x < -self.rect.width:
            self.kill()  # 移出屏幕后删除

# 定义玩家类
class Player(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.image.load("player.png")  # 替换为实际的玩家图像路径
        self.rect = self.image.get_rect()
        self.rect.x = 80  # 玩家初始位置
        self.rect.y = screen_height // 2  # 玩家初始高度居中

    def update(self):
        keys = pygame.key.get_pressed()  # 获取按键状态
        if keys[pygame.K_UP] and self.rect.top > 0:
            self.rect.y -= 5  # 向上移动
        if keys[pygame.K_DOWN] and self.rect.bottom < screen_height:
            self.rect.y += 5  # 向下移动

# 生成铃铛和礼物
def generate_bells_and_gifts(all_sprites, bells_and_gifts_group, density=0.05):
    if random.random() < density:  # 根据密度决定是否生成
        if random.choice([True, False]):  # 随机选择生成铃铛或礼物
            bell = Bell()
            bells_and_gifts_group.add(bell)
            all_sprites.add(bell)
        else:
            gift = Gift()  # 假设有一个Gift类
            bells_and_gifts_group.add(gift)
            all_sprites.add(gift)

# 生成圣诞袜
def generate_christmas_socks(all_sprites, christmas_socks_group):
    if random.random() < 0.0005:  # 30% 概率生成
        sock = ChristmasSock()
        christmas_socks_group.add(sock)
        all_sprites.add(sock)

# 生成小鸟
def generate_birds(all_sprites, birds_group):
    if random.random() < 0.001:  # 20% 概率生成
        bird = Bird()
        birds_group.add(bird)
        all_sprites.add(bird)

def handle_input(player, speed=3):
    """处理玩家输入并更新玩家的y坐标"""
    keys = pygame.key.get_pressed()  # 获取当前按键状态
    if keys[pygame.K_UP] and player.rect.top > 0:
        player.rect.y -= speed  # 向上移动
    if keys[pygame.K_DOWN] and player.rect.bottom < screen_height:
        player.rect.y += speed  # 向下移动


# 初始化 Pygame
pygame.init()

# 设置窗口
screen_width = 800
screen_height = 450
screen = pygame.display.set_mode((screen_width, screen_height), pygame.SRCALPHA)
pygame.display.set_caption("Flying Machine Game")  # 设置窗口标题

# 创建缓冲区
buffer = pygame.Surface((screen_width, screen_height), pygame.SRCALPHA)

# 加载游戏背景图片、角色图片和元素图片
background_image = pygame.image.load("background.png")
character_image = pygame.image.load("player.png")
bell_image = pygame.image.load("bell.png")
gift_image = pygame.image.load("gift.png")
speedup_image = pygame.image.load("sock.png")
blood_image = pygame.image.load("blood.png")
bird_image = pygame.image.load("bird.png")
logo_image = pygame.image.load("logo.png")
background_width = background_image.get_width()

# 加载字体
font = pygame.font.Font(None, 24)  # 使用内置字体，大小

# 加载声音效果
pygame.mixer.init()
bell_sound = pygame.mixer.Sound("score_sound.wav")

# 设置背景的初始位置
background_x1 = 0  # 第一张背景图片的初始x坐标
background_x2 = background_width  # 第二张背景图片的初始x坐标
background_speed = 2  # 背景移动速度

loop_count = 0  # 记录循环次数
max_loops = 2   # 允许背景循环的最大次数
bell_count = 0  # 铃铛计数
health = 5      # 血量
player_y = screen_height // 2  # 初始位置
clock = pygame.time.Clock()  # 游戏时钟 (控制帧率)

# 游戏主程序调用
load_game_logo()  # 显示Logo
player_name = input_player_name()  # 输入玩家姓名

# 从数据库获取机场数据
airport_codes = ('EFHK', 'EFTP', 'EFJY', 'EFKK', 'EFRO')
airport_data = get_airport_info(airport_codes)
hel_info = airport_data.get('EFHK')  # 获取第一个机场的信息

# 定义精灵组
all_sprites = pygame.sprite.Group()
bells_and_gifts_group = pygame.sprite.Group()
christmas_socks_group = pygame.sprite.Group()
birds_group = pygame.sprite.Group()

# # 创建玩家对象
player = Player()
# all_sprites.add(player)

running = True  # 主循环标志

# 游戏主循环
while running:
    # 处理事件
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False  # 退出游戏

    # 处理输入
    handle_input(player)  # 直接传入玩家对象

    # 更新元素
    all_sprites.update()  # 更新所有元素的位置

    # # 清空缓冲区
    # buffer.fill((0, 0, 0, 0))  # 填充缓冲区（可选：使用透明填充）
    #
    # # 绘制背景到缓冲区
    # buffer.blit(background_image, (background_x1, 0))
    # buffer.blit(background_image, (background_x2, 0))

    # 生成元素
    generate_bells_and_gifts(all_sprites, bells_and_gifts_group, density=0.008)  # 调整密度
    generate_christmas_socks(all_sprites, christmas_socks_group)
    generate_birds(all_sprites, birds_group)

        # 这里可以添加碰撞检测和元素获取的逻辑
        # 假设用户获取铃铛时：
        # if获得铃铛的条件:
        #     bell_count += 1
        #     bell_sound.play()

        # 假设用户受到伤害时：
        # if受到伤害的条件:
        #     health -= 1
        #     if health <= 0:
        #         running = False  # 游戏结束

    # 更新背景位置和循环计数
    loop_count = update_background()

    # 检查是否循环了两遍
    if loop_count >= max_loops:
        running = False  # 结束游戏主循环

    # 绘制游戏界面
    draw_game_screen_and_airport_info(bell_count, health, player_name, hel_info)   # 绘制游戏界面并传递当前计数和血量

    # 绘制元素
    all_sprites.draw(screen)  # 绘制所有元素

    # 绘制玩家，确保它在最后绘制
    screen.blit(player.image, player.rect)  # 最后绘制玩家图层

    # 更新屏幕
    pygame.display.update()

    # 更新游戏逻辑
    # 比如移动物体、检测碰撞等

    # 控制帧率 (60帧每秒)
    clock.tick(10)

# 退出 Pygame
pygame.quit()

